import { describe, expect, it, vi } from 'vitest';
import { getAvailability } from '@api-client/get-availability';

const known = {
  status: 'known',
  takenNights: ['2026-11-05'],
  from: '2026-11-01',
  to: '2026-12-01',
  updatedAt: '2026-11-01T10:00:00.000Z',
};

describe('getAvailability', () => {
  it('asks our own API with the cabin id encoded', async () => {
    const fetchImpl = vi.fn(async () => Response.json(known));
    expect(await getAvailability('gefen&x', fetchImpl)).toEqual(known);
    expect(fetchImpl).toHaveBeenCalledWith('/api/availability?cabin=gefen%26x', expect.anything());
  });

  it('turns an error status, bad JSON or a network failure into unknown (H7)', async () => {
    const failures = [
      async () => new Response('', { status: 500 }),
      async () => new Response('not json'),
      async () => {
        throw new TypeError('offline');
      },
    ];
    for (const fetchImpl of failures) {
      expect((await getAvailability('gefen', fetchImpl)).status).toBe('unknown');
    }
  });
});
