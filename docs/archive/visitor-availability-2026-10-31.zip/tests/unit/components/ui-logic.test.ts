import { describe, expect, it } from 'vitest';
import { nextFocusDay } from '@components/availability/grid-keyboard';
import { availabilityStatusText } from '@components/availability/status-text';
import { stayProblemText, staySummaryText } from '@components/booking/booking-text';

describe('calendar keyboard (A3)', () => {
  it('moves by day in right-to-left order, by week, and to the week ends', () => {
    expect(nextFocusDay('ArrowLeft', '2026-11-05')).toBe('2026-11-06');
    expect(nextFocusDay('ArrowRight', '2026-11-05')).toBe('2026-11-04');
    expect(nextFocusDay('ArrowDown', '2026-11-05')).toBe('2026-11-12');
    expect(nextFocusDay('ArrowUp', '2026-11-05')).toBe('2026-10-29');
    expect(nextFocusDay('Home', '2026-11-05')).toBe('2026-11-01');
    expect(nextFocusDay('End', '2026-11-05')).toBe('2026-11-07');
    expect(nextFocusDay('Enter', '2026-11-05')).toBeNull();
  });
});

describe('status and summary texts', () => {
  it('never claims free when unknown, and says why (H7, S4)', () => {
    expect(availabilityStatusText({ status: 'unknown', reason: 'stale' }, false)).toMatch(/לא התעדכנה/);
    expect(availabilityStatusText({ status: 'unknown', reason: 'calendar_unavailable' }, true)).toMatch(/טוענים/);
    expect(staySummaryText({ checkIn: '2026-11-05', checkOut: '2026-11-07' }, 'unknown')).toMatch(/אין לנו כרגע מידע/);
  });

  it('sums up a stay and only explains problems the guest can act on', () => {
    expect(staySummaryText({ checkIn: '2026-11-05', checkOut: '2026-11-06' }, 'free')).toMatch(/^05\.11\.2026 עד 06\.11\.2026, לילה אחד\./);
    expect(stayProblemText('check_in_missing', 14)).toBeNull();
    expect(stayProblemText('stay_too_long', 14)).toMatch(/14 לילות/);
  });
});
