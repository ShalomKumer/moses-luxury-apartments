import { describe, expect, it } from 'vitest';
import { buildBookingMessage, buildBookingSubject } from '@domain/booking/booking-message';
import { validateStay } from '@domain/booking/booking-request';
import { mailtoLink } from '@domain/booking/mailto-link';
import { toInternationalDigits } from '@domain/booking/phone-number';
import { selectDay } from '@domain/booking/stay-selection';
import { whatsappLink } from '@domain/booking/whatsapp-link';

const limits = { today: '2026-11-01', maxGuests: 4, maxNights: 14 };

describe('validateStay', () => {
  it('accepts a complete, sensible choice', () => {
    expect(validateStay({ checkIn: '2026-11-05', checkOut: '2026-11-07', guests: 2 }, limits)).toEqual([]);
  });

  it('names every problem', () => {
    expect(validateStay({ checkIn: null, checkOut: null, guests: null }, limits)).toEqual([
      'check_in_missing',
      'check_out_missing',
      'guests_out_of_range',
    ]);
    expect(validateStay({ checkIn: '2026-10-30', checkOut: '2026-10-29', guests: 5 }, limits)).toEqual([
      'check_in_past',
      'check_out_not_after',
      'guests_out_of_range',
    ]);
    expect(validateStay({ checkIn: '2026-11-05', checkOut: '2026-12-05', guests: 2 }, limits)).toEqual(['stay_too_long']);
  });
});

describe('selectDay', () => {
  it('picks check-in, then check-out, then starts again', () => {
    const first = selectDay({ checkIn: null, checkOut: null }, '2026-11-05');
    expect(first).toEqual({ checkIn: '2026-11-05', checkOut: null });
    const second = selectDay(first, '2026-11-07');
    expect(second).toEqual({ checkIn: '2026-11-05', checkOut: '2026-11-07' });
    expect(selectDay(second, '2026-11-10')).toEqual({ checkIn: '2026-11-10', checkOut: null });
    expect(selectDay(first, '2026-11-03')).toEqual({ checkIn: '2026-11-03', checkOut: null });
  });
});

describe('booking message', () => {
  it('lists the stay and the guests', () => {
    expect(buildBookingMessage('צימר הגפן', { checkIn: '2026-11-05', checkOut: '2026-11-07', guests: 2 })).toBe(
      'שלום, אשמח לבדוק הזמנה בצימר הגפן.\nתאריכים: 05.11.2026 עד 07.11.2026 (2 לילות)\nמספר אורחים: 2',
    );
  });

  it('leaves out what was not chosen', () => {
    expect(buildBookingMessage('צימר הגפן', { checkIn: null, checkOut: null, guests: null })).toBe(
      'שלום, אשמח לבדוק הזמנה בצימר הגפן.',
    );
    expect(buildBookingSubject('צימר הגפן')).toBe('בקשת הזמנה - צימר הגפן');
  });
});

describe('links', () => {
  it('normalises Israeli phone numbers', () => {
    expect(toInternationalDigits('050-123-4567')).toBe('972501234567');
    expect(toInternationalDigits('+972 50 123 4567')).toBe('972501234567');
    expect(toInternationalDigits('00972501234567')).toBe('972501234567');
    expect(toInternationalDigits('123')).toBeNull();
  });

  it('encodes the message into the WhatsApp and mail links', () => {
    expect(whatsappLink('972501234567', 'שלום\nא')).toBe(
      'https://wa.me/972501234567?text=%D7%A9%D7%9C%D7%95%D7%9D%0A%D7%90',
    );
    expect(mailtoLink('a@b.co', 'x y', 'z&w')).toBe('mailto:a@b.co?subject=x%20y&body=z%26w');
  });
});
