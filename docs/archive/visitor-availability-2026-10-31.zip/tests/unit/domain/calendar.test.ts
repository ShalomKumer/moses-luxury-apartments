import { describe, expect, it } from 'vitest';
import { knownResult } from '@domain/availability/availability-result';
import { compareMonths, monthGrid, shiftMonth } from '@domain/calendar/month-grid';
import { buildMonthView } from '@domain/calendar/month-view';

describe('monthGrid', () => {
  it('starts weeks on Sunday and pads with empty cells', () => {
    const weeks = monthGrid({ year: 2026, month: 11 });
    expect(weeks[0][0]).toBe('2026-11-01');
    expect(weeks.every((week) => week.length === 7)).toBe(true);
    expect(weeks.flat().filter(Boolean)).toHaveLength(30);
    const october = monthGrid({ year: 2026, month: 10 });
    expect(october[0].slice(0, 4)).toEqual([null, null, null, null]);
    expect(october[0][4]).toBe('2026-10-01');
  });

  it('moves between months and years', () => {
    expect(shiftMonth({ year: 2026, month: 12 }, 1)).toEqual({ year: 2027, month: 1 });
    expect(shiftMonth({ year: 2026, month: 1 }, -1)).toEqual({ year: 2025, month: 12 });
    expect(compareMonths({ year: 2026, month: 11 }, { year: 2027, month: 1 })).toBeLessThan(0);
  });
});

describe('buildMonthView', () => {
  it('marks status, past days and the selection, and says it all in the label', () => {
    const result = knownResult(['2026-11-05'], '2026-11-01', '2026-12-01', new Date('2026-11-01T10:00:00Z'));
    const view = buildMonthView({ year: 2026, month: 11 }, result, '2026-11-03', {
      checkIn: '2026-11-03',
      checkOut: '2026-11-05',
    });
    const cells = view.weeks.flat().filter((cell) => cell !== null);
    const byKey = (key: string) => cells.find((cell) => cell.key === key)!;
    expect(view.title).toBe('נובמבר 2026');
    expect(byKey('2026-11-02').isPast).toBe(true);
    expect(byKey('2026-11-03')).toMatchObject({ isToday: true, selection: 'check-in', status: 'free' });
    expect(byKey('2026-11-04').selection).toBe('in-stay');
    expect(byKey('2026-11-05')).toMatchObject({ status: 'taken', selection: 'check-out' });
    expect(byKey('2026-11-05').label).toBe('יום חמישי, 5 בנובמבר 2026, תפוס, תאריך יציאה');
  });
});
