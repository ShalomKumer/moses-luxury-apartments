// @ts-check
import cloudflare from '@astrojs/cloudflare';
import { defineConfig, envField, passthroughImageService } from 'astro/config';

export default defineConfig({
  // Every page is built ahead of time; only /api/availability runs on request.
  output: 'static',
  // Photos are prepared before they are added, so no image processing runs at build time or on request.
  adapter: cloudflare({ imageService: 'passthrough' }),
  image: { service: passthroughImageService() },
  // Stylesheets as files, never inline, so the CSP can stay "style-src 'self'" (S10).
  build: { inlineStylesheets: 'never' },
  // No source maps in production (S4); scripts as files, never inline, so the CSP can stay "script-src 'self'".
  vite: { build: { sourcemap: false, assetsInlineLimit: 0 } },
  env: {
    schema: {
      // {"cabin-id": "<secret iCal address>"}; set in the host's encrypted variables only (S13).
      CALENDAR_ICS_URLS: envField.string({ context: 'server', access: 'secret', optional: true }),
      // "sample" shows made-up bookings, and only on the dev server.
      AVAILABILITY_SOURCE: envField.enum({
        values: ['google', 'sample'],
        context: 'server',
        access: 'public',
        default: 'google',
      }),
    },
  },
});
