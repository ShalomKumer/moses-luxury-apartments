import type { DateKey } from '../dates/date-key';
import { countNights } from '../dates/date-range';

/** What the guest chose on the page; any part may still be missing. */
export interface StayChoice {
  checkIn: DateKey | null;
  checkOut: DateKey | null;
  guests: number | null;
}

/** A reason the choice cannot be sent yet, shown to the guest as Hebrew text chosen by this code. */
export type StayProblem =
  | 'check_in_missing'
  | 'check_in_past'
  | 'check_out_missing'
  | 'check_out_not_after'
  | 'stay_too_long'
  | 'guests_out_of_range';

/** The cabin's own limits. */
export interface StayLimits {
  today: DateKey;
  maxGuests: number;
  maxNights: number;
}

/** Lists what is missing or wrong in a choice; an empty list means it can be sent. */
export function validateStay(choice: StayChoice, limits: StayLimits): StayProblem[] {
  const problems: StayProblem[] = [];
  if (!choice.checkIn) problems.push('check_in_missing');
  else if (choice.checkIn < limits.today) problems.push('check_in_past');
  if (!choice.checkOut) problems.push('check_out_missing');
  else if (choice.checkIn && choice.checkOut <= choice.checkIn) problems.push('check_out_not_after');
  else if (choice.checkIn && countNights(choice.checkIn, choice.checkOut) > limits.maxNights) problems.push('stay_too_long');
  const guests = choice.guests;
  if (guests === null || !Number.isInteger(guests) || guests < 1 || guests > limits.maxGuests) {
    problems.push('guests_out_of_range');
  }
  return problems;
}
