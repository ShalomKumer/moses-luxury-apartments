import type { DateKey } from '../dates/date-key';

/** The dates picked on the calendar so far. */
export interface StaySelection {
  checkIn: DateKey | null;
  checkOut: DateKey | null;
}

/**
 * Applies a click on a day: the first click picks check-in, a later day picks check-out,
 * an earlier day (or any day once both are set) starts again from that day.
 */
export function selectDay(current: StaySelection, day: DateKey): StaySelection {
  const choosingCheckOut = current.checkIn !== null && current.checkOut === null && day > current.checkIn;
  if (choosingCheckOut) return { checkIn: current.checkIn, checkOut: day };
  return { checkIn: day, checkOut: null };
}
