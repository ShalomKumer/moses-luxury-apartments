import { countNights } from '../dates/date-range';
import { formatDateKey } from '../dates/format-date';
import type { StayChoice } from './booking-request';

/** Builds the pre-filled message; parts the guest has not chosen yet are left out. It holds no personal data. */
export function buildBookingMessage(cabinName: string, choice: StayChoice): string {
  const lines = [`שלום, אשמח לבדוק הזמנה ב${cabinName}.`];
  if (choice.checkIn && choice.checkOut && choice.checkOut > choice.checkIn) {
    const nights = countNights(choice.checkIn, choice.checkOut);
    const nightsText = nights === 1 ? 'לילה אחד' : `${nights} לילות`;
    lines.push(`תאריכים: ${formatDateKey(choice.checkIn)} עד ${formatDateKey(choice.checkOut)} (${nightsText})`);
  } else if (choice.checkIn) {
    lines.push(`תאריך כניסה: ${formatDateKey(choice.checkIn)}`);
  }
  if (choice.guests) lines.push(`מספר אורחים: ${choice.guests}`);
  return lines.join('\n');
}

/** Builds the subject line of the booking email. */
export function buildBookingSubject(cabinName: string): string {
  return `בקשת הזמנה - ${cabinName}`;
}
