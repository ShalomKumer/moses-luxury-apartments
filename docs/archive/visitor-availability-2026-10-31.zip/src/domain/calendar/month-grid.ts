import { addDays, dateKeyFromParts, weekday, type DateKey } from '../dates/date-key';

/** A month as year and month number (1-12). */
export interface YearMonth {
  year: number;
  month: number;
}

/** Splits a month into weeks, Sunday first; days outside the month are null. */
export function monthGrid({ year, month }: YearMonth): (DateKey | null)[][] {
  const first = dateKeyFromParts(year, month, 1);
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const cells: (DateKey | null)[] = Array(weekday(first)).fill(null);
  for (let offset = 0; offset < daysInMonth; offset++) cells.push(addDays(first, offset));
  while (cells.length % 7 !== 0) cells.push(null);
  const weeks: (DateKey | null)[][] = [];
  for (let start = 0; start < cells.length; start += 7) weeks.push(cells.slice(start, start + 7));
  return weeks;
}

/** Returns the month a number of months after (or before) the given one. */
export function shiftMonth({ year, month }: YearMonth, delta: number): YearMonth {
  const index = year * 12 + (month - 1) + delta;
  return { year: Math.floor(index / 12), month: (index % 12) + 1 };
}

/** Compares two months: negative if a is earlier, zero if equal, positive if later. */
export function compareMonths(a: YearMonth, b: YearMonth): number {
  return a.year * 12 + a.month - (b.year * 12 + b.month);
}
