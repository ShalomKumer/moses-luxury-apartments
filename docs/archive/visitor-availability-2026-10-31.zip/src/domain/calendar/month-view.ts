import { nightStatus } from '../availability/night-status';
import type { AvailabilityResult, NightStatus } from '../availability/types';
import type { StaySelection } from '../booking/stay-selection';
import { dateKeyParts, weekday, type DateKey } from '../dates/date-key';
import { formatDayLabel, formatMonthTitle } from '../dates/format-date';
import { monthGrid, type YearMonth } from './month-grid';

/** Where a day stands in the guest's selection. */
export type SelectionRole = 'none' | 'check-in' | 'check-out' | 'in-stay';

/** Everything the calendar needs to draw one day. */
export interface DayCell {
  key: DateKey;
  dayNumber: number;
  status: NightStatus;
  isPast: boolean;
  isToday: boolean;
  selection: SelectionRole;
  label: string;
}

/** One month ready to draw. */
export interface MonthView {
  title: string;
  weeks: (DayCell | null)[][];
}

const STATUS_TEXT: Record<NightStatus, string> = { free: 'פנוי', taken: 'תפוס', unknown: 'זמינות לא ידועה' };
const SELECTION_TEXT: Record<SelectionRole, string> = {
  none: '',
  'check-in': 'תאריך כניסה',
  'check-out': 'תאריך יציאה',
  'in-stay': 'בתוך השהות שנבחרה',
};

/** Says how a day relates to the selected stay. */
export function selectionRole(day: DateKey, selection: StaySelection): SelectionRole {
  if (day === selection.checkIn) return 'check-in';
  if (day === selection.checkOut) return 'check-out';
  const inside = selection.checkIn && selection.checkOut && day > selection.checkIn && day < selection.checkOut;
  return inside ? 'in-stay' : 'none';
}

/** Builds the spoken label of a day: its date, its night's status, and its role in the selection. */
export function dayLabel(day: DateKey, status: NightStatus, isPast: boolean, role: SelectionRole): string {
  const parts = [formatDayLabel(day, weekday(day)), isPast ? 'תאריך שעבר' : STATUS_TEXT[status], SELECTION_TEXT[role]];
  return parts.filter(Boolean).join(', ');
}

/** Builds one month of cells from the availability reading, today and the selection. */
export function buildMonthView(
  month: YearMonth,
  result: AvailabilityResult,
  today: DateKey,
  selection: StaySelection,
): MonthView {
  const toCell = (key: DateKey | null): DayCell | null => {
    if (!key) return null;
    const isPast = key < today;
    const status = nightStatus(result, key);
    const role = selectionRole(key, selection);
    return { key, dayNumber: dateKeyParts(key).day, status, isPast, isToday: key === today, selection: role, label: dayLabel(key, status, isPast, role) };
  };
  return { title: formatMonthTitle(month.year, month.month), weeks: monthGrid(month).map((week) => week.map(toCell)) };
}
