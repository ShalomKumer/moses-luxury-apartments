import type { APIRoute } from 'astro';
import { getCollection } from 'astro:content';
import { AVAILABILITY_SOURCE, CALENDAR_ICS_URLS } from 'astro:env/server';
import { AVAILABILITY_CONFIG } from '@config/availability';
import { getAvailabilityService } from '@server/availability-runtime';
import { errorResponse, jsonResponse } from '@server/http-response';
import { logAvailability } from '@server/log';

/** Runs on request, on the server; every other page is built ahead of time. */
export const prerender = false;

/** GET /api/availability?cabin=<id>: the taken nights of one cabin, or "unknown". Read-only. */
export const GET: APIRoute = async ({ url }) => {
  const cabinId = url.searchParams.get('cabin') ?? '';
  const cabins = await getCollection('cabins');
  if (!cabins.some((cabin) => cabin.id === cabinId)) {
    logAvailability(cabinId, 'unknown_cabin');
    return errorResponse('unknown_cabin', 404);
  }
  const service = getAvailabilityService({
    source: AVAILABILITY_SOURCE,
    calendarUrlsJson: CALENDAR_ICS_URLS,
    isDev: import.meta.env.DEV,
  });
  return jsonResponse(await service(cabinId), 200, AVAILABILITY_CONFIG.responseCacheSeconds);
};
