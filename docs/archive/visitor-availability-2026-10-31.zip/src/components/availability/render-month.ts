import type { DayCell, MonthView } from '@domain/calendar/month-view';
import type { DateKey } from '@domain/dates/date-key';
import { weekdayInitials, weekdayNames } from '@domain/dates/format-date';

/** Builds the header row of weekday letters, each with its full name for screen readers. */
function headerRow(): HTMLTableRowElement {
  const row = document.createElement('tr');
  const names = weekdayNames();
  weekdayInitials().forEach((initial, index) => {
    const th = document.createElement('th');
    th.scope = 'col';
    const abbr = document.createElement('abbr');
    abbr.title = names[index];
    abbr.textContent = initial;
    th.append(abbr);
    row.append(th);
  });
  return row;
}

/** Builds the button of one day; its status is shown by text, pattern and colour together (A1). */
function dayButton(cell: DayCell, focusDay: DateKey): HTMLButtonElement {
  const button = document.createElement('button');
  button.type = 'button';
  button.dataset.day = cell.key;
  button.className = ['day', `day--${cell.isPast ? 'past' : cell.status}`, `day--${cell.selection}`].join(' ');
  button.setAttribute('aria-label', cell.label);
  button.setAttribute('aria-pressed', String(cell.selection === 'check-in' || cell.selection === 'check-out'));
  button.tabIndex = cell.key === focusDay ? 0 : -1;
  if (cell.isPast) button.setAttribute('aria-disabled', 'true');
  if (cell.isToday) button.setAttribute('aria-current', 'date');
  button.textContent = String(cell.dayNumber);
  return button;
}

/** Builds one week row; days outside the month are empty cells. */
function weekRow(week: (DayCell | null)[], focusDay: DateKey): HTMLTableRowElement {
  const row = document.createElement('tr');
  for (const cell of week) {
    const td = document.createElement('td');
    if (cell) td.append(dayButton(cell, focusDay));
    row.append(td);
  }
  return row;
}

/** Draws a month as a table of day buttons into the container, replacing what was there. */
export function renderMonth(container: HTMLElement, view: MonthView, focusDay: DateKey): void {
  const table = document.createElement('table');
  table.className = 'month';
  const caption = document.createElement('caption');
  caption.className = 'visually-hidden';
  caption.textContent = view.title;
  const head = document.createElement('thead');
  head.append(headerRow());
  const body = document.createElement('tbody');
  view.weeks.forEach((week) => body.append(weekRow(week, focusDay)));
  table.append(caption, head, body);
  container.replaceChildren(table);
}
