import { getAvailability } from '@api-client/get-availability';
import { AVAILABILITY_CONFIG } from '@config/availability';
import { unknownResult, withFreshness } from '@domain/availability/availability-result';
import type { AvailabilityResult } from '@domain/availability/types';
import { selectDay, type StaySelection } from '@domain/booking/stay-selection';
import { compareMonths, shiftMonth, type YearMonth } from '@domain/calendar/month-grid';
import { buildMonthView } from '@domain/calendar/month-view';
import { dateKeyFromParts, dateKeyParts, toDateKey, type DateKey } from '@domain/dates/date-key';
import { nextFocusDay } from './grid-keyboard';
import { renderMonth } from './render-month';
import { dispatchStayChange } from './stay-change-event';
import { availabilityStatusText } from './status-text';

/** The calendar's elements. */
interface CalendarParts {
  grid: HTMLElement;
  title: HTMLElement;
  status: HTMLElement;
  prev: HTMLButtonElement;
  next: HTMLButtonElement;
}

/** Everything the calendar shows, in one place. */
interface CalendarState {
  cabinId: string;
  today: DateKey;
  first: YearMonth;
  last: YearMonth;
  month: YearMonth;
  focusDay: DateKey;
  selection: StaySelection;
  result: AvailabilityResult;
  loading: boolean;
  fetchedAt: number;
}

/** Finds the calendar's elements; returns null if the markup is incomplete. */
function findParts(root: HTMLElement): CalendarParts | null {
  const grid = root.querySelector<HTMLElement>('[data-calendar-grid]');
  const title = root.querySelector<HTMLElement>('[data-calendar-title]');
  const status = root.querySelector<HTMLElement>('[data-calendar-status]');
  const prev = root.querySelector<HTMLButtonElement>('[data-calendar-prev]');
  const next = root.querySelector<HTMLButtonElement>('[data-calendar-next]');
  return grid && title && status && prev && next ? { grid, title, status, prev, next } : null;
}

/** Returns the month a day falls in. */
function monthOf(day: DateKey): YearMonth {
  const { year, month } = dateKeyParts(day);
  return { year, month };
}

/** Builds the starting state for a cabin, from today. */
function initialState(cabinId: string): CalendarState {
  const today = toDateKey(new Date());
  const first = monthOf(today);
  return {
    cabinId,
    today,
    first,
    last: shiftMonth(first, AVAILABILITY_CONFIG.monthsAhead - 1),
    month: first,
    focusDay: today,
    selection: { checkIn: null, checkOut: null },
    result: unknownResult('calendar_unavailable'),
    loading: true,
    fetchedAt: 0,
  };
}

/** Returns the reading as it may be shown now: too old becomes unknown (H7). */
function currentResult(state: CalendarState): AvailabilityResult {
  return withFreshness(state.result, new Date(), AVAILABILITY_CONFIG.staleAfterMs);
}

/** Draws the month, the navigation and the status line; keeps focus on the same day if it was in the grid. */
function draw(parts: CalendarParts, state: CalendarState): void {
  const hadFocus = parts.grid.contains(document.activeElement);
  const view = buildMonthView(state.month, currentResult(state), state.today, state.selection);
  parts.title.textContent = view.title;
  renderMonth(parts.grid, view, state.focusDay);
  parts.prev.disabled = compareMonths(state.month, state.first) <= 0;
  parts.next.disabled = compareMonths(state.month, state.last) >= 0;
  parts.status.textContent = availabilityStatusText(currentResult(state), state.loading);
  if (hadFocus) parts.grid.querySelector<HTMLButtonElement>(`[data-day="${state.focusDay}"]`)?.focus();
}

/** Moves focus to a day, changing month if needed; days outside the shown months are ignored. */
function moveFocus(parts: CalendarParts, state: CalendarState, day: DateKey): void {
  const month = monthOf(day);
  if (day < state.today || compareMonths(month, state.last) > 0) return;
  state.focusDay = day;
  state.month = month;
  draw(parts, state);
  parts.grid.querySelector<HTMLButtonElement>(`[data-day="${day}"]`)?.focus();
}

/** Changes the shown month by delta and puts the focus day inside it. */
function changeMonth(parts: CalendarParts, state: CalendarState, delta: number): void {
  state.month = shiftMonth(state.month, delta);
  const firstDay = dateKeyFromParts(state.month.year, state.month.month, 1);
  state.focusDay = firstDay < state.today ? state.today : firstDay;
  draw(parts, state);
}

/** Wires day clicks and arrow keys in the grid. */
function bindGrid(root: HTMLElement, parts: CalendarParts, state: CalendarState): void {
  parts.grid.addEventListener('click', (event) => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('[data-day]');
    if (!button || button.getAttribute('aria-disabled') === 'true') return;
    state.selection = selectDay(state.selection, button.dataset.day as DateKey);
    state.focusDay = button.dataset.day as DateKey;
    draw(parts, state);
    dispatchStayChange(root, { cabinId: state.cabinId, selection: state.selection, result: currentResult(state) });
  });
  parts.grid.addEventListener('keydown', (event) => {
    const target = nextFocusDay(event.key, state.focusDay);
    if (!target) return;
    event.preventDefault();
    moveFocus(parts, state, target);
  });
}

/** Reads the availability from the API and redraws; refreshes when the page comes back into view. */
function bindLoading(root: HTMLElement, parts: CalendarParts, state: CalendarState): void {
  const load = async () => {
    state.result = await getAvailability(state.cabinId);
    state.loading = false;
    state.fetchedAt = Date.now();
    draw(parts, state);
    dispatchStayChange(root, { cabinId: state.cabinId, selection: state.selection, result: currentResult(state) });
  };
  document.addEventListener('visibilitychange', () => {
    const old = Date.now() - state.fetchedAt > AVAILABILITY_CONFIG.cacheMs;
    if (document.visibilityState === 'visible' && old) void load();
  });
  setInterval(() => draw(parts, state), 60 * 1000);
  void load();
}

/** Starts one availability calendar: draws the current month and loads the cabin's taken nights. */
export function initAvailabilityCalendar(root: HTMLElement): void {
  const parts = findParts(root);
  if (!parts) return;
  const state = initialState(root.dataset.cabinId ?? '');
  root.hidden = false;
  parts.prev.addEventListener('click', () => changeMonth(parts, state, -1));
  parts.next.addEventListener('click', () => changeMonth(parts, state, 1));
  bindGrid(root, parts, state);
  draw(parts, state);
  bindLoading(root, parts, state);
}
