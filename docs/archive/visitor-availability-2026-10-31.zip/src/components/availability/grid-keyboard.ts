import { addDays, weekday, type DateKey } from '@domain/dates/date-key';

/**
 * Returns the day a key press moves focus to, or null for any other key. The page is right to left,
 * so the left arrow moves to the next day and the right arrow to the previous one (A3).
 */
export function nextFocusDay(key: string, day: DateKey): DateKey | null {
  switch (key) {
    case 'ArrowLeft':
      return addDays(day, 1);
    case 'ArrowRight':
      return addDays(day, -1);
    case 'ArrowDown':
      return addDays(day, 7);
    case 'ArrowUp':
      return addDays(day, -7);
    case 'Home':
      return addDays(day, -weekday(day));
    case 'End':
      return addDays(day, 6 - weekday(day));
    default:
      return null;
  }
}
