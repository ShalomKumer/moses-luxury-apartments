import type { AvailabilityResult, UnknownReason } from '@domain/availability/types';
import { formatTimeOfDay } from '@domain/dates/format-date';

const ASK_US = 'אפשר לשאול אותנו בוואטסאפ או במייל, ונבדוק עבורכם.';

const UNKNOWN_TEXT: Record<UnknownReason, string> = {
  calendar_unavailable: `לא הצלחנו לטעון את הזמינות כרגע. ${ASK_US}`,
  stale: `הזמינות לא התעדכנה לאחרונה, ולכן היא לא מוצגת. ${ASK_US}`,
  not_configured: `הזמינות של הצימר הזה עדיין לא מחוברת לאתר. ${ASK_US}`,
};

/** Returns the Hebrew line under the calendar, chosen by the result's status and reason code (S4, H7). */
export function availabilityStatusText(result: AvailabilityResult, loading: boolean): string {
  if (loading) return 'טוענים את הזמינות…';
  if (result.status === 'unknown') return UNKNOWN_TEXT[result.reason];
  return `הזמינות עודכנה בשעה ${formatTimeOfDay(result.updatedAt)}. ההזמנה נקבעת רק לאחר אישור שלנו.`;
}
