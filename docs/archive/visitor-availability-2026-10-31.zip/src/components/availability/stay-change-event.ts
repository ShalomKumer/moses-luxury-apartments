import type { AvailabilityResult } from '@domain/availability/types';
import type { StaySelection } from '@domain/booking/stay-selection';

/** The event the calendar sends when the selection or the availability changes. */
export const STAY_CHANGE_EVENT = 'stay-change';

/** What the event carries. */
export interface StayChangeDetail {
  cabinId: string;
  selection: StaySelection;
  result: AvailabilityResult;
}

/** Sends the event from the calendar; it bubbles to the document, where the booking panel listens. */
export function dispatchStayChange(source: HTMLElement, detail: StayChangeDetail): void {
  source.dispatchEvent(new CustomEvent<StayChangeDetail>(STAY_CHANGE_EVENT, { bubbles: true, detail }));
}
