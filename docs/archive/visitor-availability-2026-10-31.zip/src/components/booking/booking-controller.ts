import { unknownResult } from '@domain/availability/availability-result';
import { stayStatus } from '@domain/availability/night-status';
import type { AvailabilityResult } from '@domain/availability/types';
import { buildBookingMessage, buildBookingSubject } from '@domain/booking/booking-message';
import { validateStay, type StayChoice } from '@domain/booking/booking-request';
import { mailtoLink } from '@domain/booking/mailto-link';
import type { StaySelection } from '@domain/booking/stay-selection';
import { whatsappLink } from '@domain/booking/whatsapp-link';
import { toDateKey } from '@domain/dates/date-key';
import { STAY_CHANGE_EVENT, type StayChangeDetail } from '../availability/stay-change-event';
import { stayProblemText, staySummaryText } from './booking-text';

/** The panel's settings, read from its data attributes. */
interface PanelSettings {
  cabinId: string;
  cabinName: string;
  maxGuests: number;
  maxNights: number;
  phoneDigits: string | null;
  email: string;
}

/** The panel's elements. */
interface PanelParts {
  guests: HTMLSelectElement;
  summary: HTMLElement;
  problems: HTMLElement;
  whatsapp: HTMLAnchorElement | null;
  email: HTMLAnchorElement | null;
}

/** Reads the settings the page wrote on the panel. */
function readSettings(root: HTMLElement): PanelSettings {
  const data = root.dataset;
  return {
    cabinId: data.cabinId ?? '',
    cabinName: data.cabinName ?? '',
    maxGuests: Number(data.maxGuests),
    maxNights: Number(data.maxNights),
    phoneDigits: data.phoneDigits || null,
    email: data.email ?? '',
  };
}

/** Finds the panel's elements; returns null if the markup is incomplete, leaving the plain links working. */
function findParts(root: HTMLElement): PanelParts | null {
  const guests = root.querySelector<HTMLSelectElement>('[data-booking-guests]');
  const summary = root.querySelector<HTMLElement>('[data-booking-summary]');
  const problems = root.querySelector<HTMLElement>('[data-booking-problems]');
  if (!guests || !summary || !problems) return null;
  const whatsapp = root.querySelector<HTMLAnchorElement>('[data-booking-whatsapp]');
  const email = root.querySelector<HTMLAnchorElement>('[data-booking-email]');
  return { guests, summary, problems, whatsapp, email };
}

/** Rewrites the two links so the message carries the chosen dates and guests. */
function updateLinks(parts: PanelParts, settings: PanelSettings, choice: StayChoice): void {
  const message = buildBookingMessage(settings.cabinName, choice);
  if (parts.whatsapp && settings.phoneDigits) parts.whatsapp.href = whatsappLink(settings.phoneDigits, message);
  if (parts.email) parts.email.href = mailtoLink(settings.email, buildBookingSubject(settings.cabinName), message);
}

/** Writes the stay summary and any problem the guest can fix. */
function updateTexts(parts: PanelParts, settings: PanelSettings, choice: StayChoice, result: AvailabilityResult): void {
  const selection: StaySelection = { checkIn: choice.checkIn, checkOut: choice.checkOut };
  const status = choice.checkIn && choice.checkOut ? stayStatus(result, choice.checkIn, choice.checkOut) : 'unknown';
  parts.summary.textContent = staySummaryText(selection, status);
  const limits = { today: toDateKey(new Date()), maxGuests: settings.maxGuests, maxNights: settings.maxNights };
  const texts = validateStay(choice, limits)
    .map((problem) => stayProblemText(problem, settings.maxNights))
    .filter((text): text is string => text !== null);
  parts.problems.textContent = texts.join(' ');
}

/** Starts a booking panel: listens to its cabin's calendar and the guests field, and keeps the links current. */
export function initBookingPanel(root: HTMLElement): void {
  const parts = findParts(root);
  if (!parts) return;
  const settings = readSettings(root);
  let selection: StaySelection = { checkIn: null, checkOut: null };
  let result: AvailabilityResult = unknownResult('calendar_unavailable');
  const update = () => {
    const choice: StayChoice = { ...selection, guests: Number(parts.guests.value) || null };
    updateLinks(parts, settings, choice);
    updateTexts(parts, settings, choice, result);
  };

  document.addEventListener(STAY_CHANGE_EVENT, (event) => {
    const detail = (event as CustomEvent<StayChangeDetail>).detail;
    if (detail.cabinId !== settings.cabinId) return;
    selection = detail.selection;
    result = detail.result;
    update();
  });
  parts.guests.addEventListener('change', update);
  update();
}
