import type { NightStatus } from '@domain/availability/types';
import type { StayProblem } from '@domain/booking/booking-request';
import { countNights } from '@domain/dates/date-range';
import { formatDateKey } from '@domain/dates/format-date';
import type { StaySelection } from '@domain/booking/stay-selection';

const STAY_STATUS_TEXT: Record<NightStatus, string> = {
  free: 'לפי היומן שלנו כל הלילות האלה פנויים. ההזמנה נקבעת רק לאחר אישור שלנו.',
  taken: 'חלק מהלילות האלה תפוסים. אפשר לבחור תאריכים אחרים, או לשאול אותנו.',
  unknown: 'אין לנו כרגע מידע אם הלילות האלה פנויים. נבדוק ונחזור אליכם.',
};

/** Returns the line that sums up the chosen stay, with what the calendar says about it. */
export function staySummaryText(selection: StaySelection, status: NightStatus): string {
  if (!selection.checkIn) return 'עוד לא נבחרו תאריכים. אפשר לבחור בלוח הזמינות, או לשאול אותנו ישירות.';
  if (!selection.checkOut) return `תאריך כניסה: ${formatDateKey(selection.checkIn)}. עכשיו בחרו תאריך יציאה.`;
  const nights = countNights(selection.checkIn, selection.checkOut);
  const nightsText = nights === 1 ? 'לילה אחד' : `${nights} לילות`;
  return `${formatDateKey(selection.checkIn)} עד ${formatDateKey(selection.checkOut)}, ${nightsText}. ${STAY_STATUS_TEXT[status]}`;
}

/** Returns the Hebrew text of a problem the guest can act on; problems of a choice not yet made have none. */
export function stayProblemText(problem: StayProblem, maxNights: number): string | null {
  switch (problem) {
    case 'check_in_past':
      return 'תאריך הכניסה כבר עבר.';
    case 'check_out_not_after':
      return 'תאריך היציאה צריך להיות אחרי תאריך הכניסה.';
    case 'stay_too_long':
      return `אפשר להזמין כאן עד ${maxNights} לילות. לשהות ארוכה יותר כתבו לנו.`;
    default:
      return null;
  }
}
