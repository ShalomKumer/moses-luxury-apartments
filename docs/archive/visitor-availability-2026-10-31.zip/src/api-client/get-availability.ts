import { parseAvailabilityResult, unknownResult } from '@domain/availability/availability-result';
import type { AvailabilityResult } from '@domain/availability/types';

/** Asks our own API for a cabin's availability; any failure comes back as "unknown", never as free (H7). */
export async function getAvailability(cabinId: string, fetchImpl: typeof fetch = fetch): Promise<AvailabilityResult> {
  try {
    const response = await fetchImpl(`/api/availability?cabin=${encodeURIComponent(cabinId)}`, {
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) return unknownResult('calendar_unavailable');
    return parseAvailabilityResult(await response.json());
  } catch {
    return unknownResult('calendar_unavailable');
  }
}
